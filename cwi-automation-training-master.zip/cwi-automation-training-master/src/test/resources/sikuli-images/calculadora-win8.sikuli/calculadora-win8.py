"botao-igual.png"
"resultado-20.png"